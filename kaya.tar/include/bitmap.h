#ifndef BITMAP_H
#define BITMAP_H

extern int get_bit_num(int bitmask);
extern int get_bit_mask(int bit);
extern int find_dev_mask(int dev);

#endif
